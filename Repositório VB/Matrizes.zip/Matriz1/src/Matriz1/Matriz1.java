/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Matriz1;

/**
 *
 * @author VINICIUSOLIVEIRABAST
 */
public class Matriz1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       //Criando nova String
       String[] Ferramentas;
       Ferramentas = new String[15];
       
       //Criando a lista com os elementos
       Ferramentas[0]="Martelo";
       Ferramentas[1]="Chave de fenda";
       Ferramentas[2]="Serrote";
       Ferramentas[3]="Arco de serra";
       Ferramentas[4]="Marreta";
       Ferramentas[5]="Chave inglesa ";
       Ferramentas[6]="Trena";
       Ferramentas[7]="Fita Métrica";
       Ferramentas[8]="Serra Tico-Tico";
       Ferramentas[9]="Ferro de Solda";
       Ferramentas[10]="Colher de Pedreiro";
       Ferramentas[11]="Nível";
       Ferramentas[12]="Tesoura";
       Ferramentas[13]="Chave Allen";
       Ferramentas[14]="Chave Philips";
     //Indices que devem aparecer na 1ª Matriz- 1,4,6,14,10,13,8,e 9.      
    System.out.println("Elemento no índice 1: " + Ferramentas[1]);
    System.out.println("Elemento no índice 4: " + Ferramentas[4]);
    System.out.println("Elemento no índice 6: " + Ferramentas[6]);
    System.out.println("Elemento no índice 14: "+ Ferramentas[14]);
    System.out.println("Elemento no índice 10: "+ Ferramentas[10]);
    System.out.println("Elemento no índice 13: "+ Ferramentas[13]);
    System.out.println("Elemento no índice 8: " + Ferramentas[8]);
    System.out.println("Elemento no índice 9: " + Ferramentas[9]);
    }
}
