/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package matriz2;

/**
 *
 * @author VINICIUSOLIVEIRABAST
 */
public class Matriz2 {

    
    public static void main(String[] args) {
        //Criando nova String
        String[] Marcas;
        Marcas = new String [16];
        //Criando a lista com os elementos
        Marcas [0] =  "OLG";
        Marcas [1] =  "AOC";
        Marcas [2] =  "Chevrolet";
        Marcas [3] =  "HP";
        Marcas [4] =  "Microsoft";
        Marcas [5] =  "Electrolux";
        Marcas [6] =  "McDonalds'";
        Marcas [7] =  "Burger King";
        Marcas [8] =  "KFC";
        Marcas [9] =  "Xbox";
        Marcas [10] = "Playstation";
        Marcas [11] = "Adidas";
        Marcas [12] = "Nike";
        Marcas [13] = "Puma";
        Marcas [14] = "EA9";
        Marcas [15] = "Google";
        
    //Indices que devem mostrar na 2ª Matriz - 0,3,7,11,5,2,12 e 15.
     System.out.println("Elemento no indice 0: " + Marcas[0] );
     System.out.println("Elemento no indice 3: " + Marcas[3] );
     System.out.println("Elemento no indice 7: " + Marcas[7]);
     System.out.println("Elemento no indice 11: " + Marcas[11]);
     System.out.println("Elemento no indice 5: " + Marcas[5]);
     System.out.println("Elemento no indice 2: " + Marcas[2]);
     System.out.println("Elemento no indice 12: " + Marcas[12]);
     System.out.println("Elemento no indice 15: " + Marcas[15]);
    }
    
}
