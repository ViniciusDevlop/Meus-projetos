/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.matriz;
public class Matriz {
public static void main(String[] args) {
    //Issp daqui foi o exemplo que o professor nos deu.
// Declara uma matriz de inteiros com capacidade para 5 elementos
int[] numeros;
numeros = new int[10];
// Atribui valores aos elementos da matriz
numeros[0] = 10;
numeros[1] = 20;
numeros[2] = 30;
numeros[3] = 40;
numeros[4] = 50;
numeros[5] = 80;
// Acessa e imprime os elementos da matriz
System.out.println("Elemento no índice 0: " + numeros[0]); //
//Saída: Elemento no índice 0: 10
System.out.println("Elemento no índice 3: " + numeros[3]); //
//Saída: Elemento no índice 3: 40
System.out.println("Elemento no índice 5: " + numeros[5]);
 }
}